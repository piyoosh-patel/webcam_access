import CameraComponent from './CameraComponent '
import './App.css'

function App() {
  
  return (
    <>
  <h1>welcome</h1>
  <CameraComponent />
    </>
  )
}

export default App
