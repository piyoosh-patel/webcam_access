import React, { useState } from 'react';
import Webcam from 'react-webcam';
import axios from 'axios'

const CameraComponent = () => {
  const webcamRef = React.useRef(null);
  const [uploadedImage, setUploadedImage] = useState(null);
  const [showCamera, setShowCamera] = useState(false);

 

  const handleCapture = async () => {
  const imageSrc = webcamRef.current.getScreenshot();
  setUploadedImage(imageSrc);
  setShowCamera(false); // Hide the camera interface after capturing

  try {
    // Convert base64 image data to Blob
    // const base64Response = await fetch(imageSrc);
    // const blob = await base64Response.blob();
    
    // Create FormData object and append data
    const formData = new FormData();
    // formData.append('file', blob); 
    formData.append('user_id', '1429c494-41e8-ee11-a81e-002248e60389'); 
    formData.append('document_id', imageSrc); 
    console.log("before resposne")

    const response = await axios.post('https://eacademyeducation.com:3113/v1/documents/upload-document', formData, {
      headers: {
        'Content-Type': 'multipart/form-data'
      }
    });
    
    // const response = await axios.get("https://eacademyeducation.com:3113/v1/users/user-details?id=1429c494-41e8-ee11-a81e-002248e60389", response);
    console.log("after resposne", response)
    
    // if (!response.ok) {
    //     throw new Error(`Failed to send image to the API: ${response.statusText}`);
    // }

    // Handle success response here
  } catch (error) {
    console.error('Error sending image to the API:', error);
    // Handle error here
  }
};


  const handleUpload = () => {
    // Trigger the file input click
    document.getElementById('fileInput').click();
  };

  const handleFileChange = (event) => {
    const file = event.target.files[0];
    const reader = new FileReader();

    reader.onloadend = () => {
      setUploadedImage(reader.result);
    };

    if (file) {
      reader.readAsDataURL(file);
    }
  };

  return (
    <div>
      {showCamera && (
        <div>
          <Webcam
            audio={false}
            ref={webcamRef}
            screenshotFormat="image/jpeg"
            style={{ display: uploadedImage ? 'none' : 'block' }}
          />
          <button onClick={handleCapture}>Capture</button>
        </div>
      )}
      {!showCamera && !uploadedImage && (
        <button onClick={() => setShowCamera(true)}>Open Camera</button>
      )}
      {!showCamera && (
        <div>
          <button onClick={handleUpload}>Upload from Computer</button>
          <input
            type="file"
            id="fileInput"
            accept="image/*"
            onChange={handleFileChange}
            style={{ display: 'none' }}
          />
        </div>
      )}
      {uploadedImage && (
        <div>
          <img src={uploadedImage} alt="Uploaded" />
          <button onClick={() => setUploadedImage(null)}>Re-capture / Upload New</button>
        </div>
      )}
    </div>
  );
};

export default CameraComponent;
